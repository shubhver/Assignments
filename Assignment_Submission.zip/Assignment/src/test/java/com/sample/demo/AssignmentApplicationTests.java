package com.sample.demo;

//@SpringBootTest
class AssignmentApplicationTests {

	/*
	 * @Test void contextLoads() { }
	 */

}
